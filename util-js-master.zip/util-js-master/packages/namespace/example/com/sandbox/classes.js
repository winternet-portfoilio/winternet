
Namespace('com.sandbox.classes', {

	MyClass1: function() {
		com.sandbox.Console.log('MyClass1');
		return {};
	},
	
	MyClass2: function() {
		com.sandbox.Console.log('MyClass2');
		return {};
	}

});
